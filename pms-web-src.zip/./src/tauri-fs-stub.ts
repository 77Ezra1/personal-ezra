export async function readTextFile() {
  return ''
}

export async function writeTextFile() {
  return undefined
}

export async function writeFile() {
  return undefined
}

export async function mkdir() {
  return undefined
}

export async function remove() {
  return undefined
}

export async function exists() {
  return false
}

export const BaseDirectory = { AppData: 'AppData' as const }
