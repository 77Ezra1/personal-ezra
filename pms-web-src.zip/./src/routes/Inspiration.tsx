import { InspirationPanel } from './Docs/InspirationPanel'

export default function Inspiration() {
  return (
    <div className="space-y-8">
      <section>
        <InspirationPanel />
      </section>
    </div>
  )
}
