import { describe, it, expect } from 'vitest'

describe('offline manager', () => {
  it('runs basic arithmetic', () => {
    expect(1 + 1).toBe(2)
  })
})
